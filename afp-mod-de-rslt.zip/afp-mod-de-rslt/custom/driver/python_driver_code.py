import sys
import numpy as np
import pandas as pd
import yaml
import logging
import boto3
import time
import datetime
import subprocess
from botocore.exceptions import ClientError
from urllib.parse import unquote_plus
from datetime import date
from awsglue.utils import getResolvedOptions
from cisdt_utility_lib_py.custom_json_logger import GlueJsonLogFilter
from cisdt_utility_lib_py.redshift_connect_pyscopg2 import RedshiftManager
import builtins as p
import datetime
import time
from datetime import date, timedelta
from pandas.tseries.offsets import BMonthEnd
import datetime as dt
import dateutil.relativedelta
from dateutil.relativedelta import relativedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, Color, PatternFill, Alignment
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from pandas import ExcelWriter
from decimal import Decimal


project_name = 'cis-models'
model_name = 'AFP'
countrycode ='DE'
country_model ='de-afp-rslt'


today = datetime.date.today()
today_fmt = today.strftime('%d/%m/%y %H:%M')
today = dt.datetime.strptime(today_fmt, '%d/%m/%y %H:%M')
this_monday = today - relativedelta(days = today.weekday())
Mod_end = this_monday.strftime("%Y-%m-%d")
Mod_start = (this_monday - relativedelta(days =7*52)).strftime("%Y-%m-%d")


#current month
mydate = today
mon = mydate.strftime("%b")
year =mydate.strftime("%y")
current_mon = mon + year
year =mydate.strftime("%y")
year_1=mydate + relativedelta(years=-1)
year_1 = year_1.strftime("%y")
year =mydate.strftime("%y")
month = int(mydate.strftime("%m"))

#Calculating base month from the current month
if month ==1:
    base_month = "Nov" + str(year_1)
elif month <5:
    base_month = "Feb" + str(year)
elif month >= 5 and month < 8:
    base_month = "May" + str(year)
elif month >=8 and month< 11:
    base_month = "Aug" + str(year) 
elif month >=11 and month<=12:
    base_month = "Nov" + str(year)


currmonth = today.replace(day=1)
month_1 = (currmonth + relativedelta(months=0)).strftime('%Y-%m-%d %H:%M:%S')
month_2 = (currmonth - relativedelta(months=2)).strftime('%Y-%m-%d %H:%M:%S')
run_date=today.strftime('%Y-%m-%d %H:%M:%S')
current_mon = mydate.strftime("%b%y")
lta_month = mydate.strftime("%Y-%m")
day = int(mydate.strftime("%d"))

end_date = mydate.replace(day=1)
end_date = end_date.strftime("%Y-%m-%d")
month1_num =  mydate.replace(day=1) + relativedelta(months=-1)
month1 = month1_num.strftime("%m")
year_now = month1_num.strftime("%Y")
last_year = month1_num + relativedelta(years=-1)
last_year = last_year.strftime("%Y")
cal_day = month1_num.strftime("%Y%m")
cal_day_1 = month1_num.strftime("%Y-%m")
offset = BMonthEnd()

#Last day of previous month
last_work_day = offset.rollback(mydate)
last_work_day_1=last_work_day.strftime("%d/%m/%Y")
last_work_day_2=last_work_day.strftime("%d_%m_%y")
st_off = 'st_off_' + last_work_day.strftime("%d_%m")

class final_mdl(object):
    def __init__(self, cli_args=None):  
        self.glue_args = self._get_glue_args(cli_args=cli_args)
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
        self.subtenant = self.glue_args['SUBTENANT']
        self.pipeline = self.glue_args['PIPELINE']
        self.execution_id = self.glue_args['PEH_ID']
        self.account = self.glue_args['ACCOUNT']
        self.tenant = self.glue_args['TENANT']
        self.env_execution = self.glue_args['ENV']
        self.conform_bucket = f'{self.account}-{self.tenant}-{self.env_execution}-conform'  
        self.enrich_bucket =  f'{self.account}-{self.tenant}-{self.env_execution}-enrich'                                                                                  
        self.transform_bucket = f'{self.account}-{self.tenant}-{self.env_execution}-transform'   
        self.ml_bucket = f'{self.account}-{self.tenant}-{self.env_execution}-machinelearning'  
        self.raw_bucket = f'{self.account}-{self.tenant}-{self.env_execution}-raw'  
        self.yaml_config_path = self.glue_args['YAML_CONFIG_PATH']
        self.unload_iam_role = self.glue_args['UNLOAD_IAM_ROLE']
        self.secret_client = boto3.client('secretsmanager')
        self.s3_client = boto3.client('s3')
        self.s3_resource = boto3.resource('s3')
        self.glue_client = boto3.client('glue')


        #Custom Parameters
        self.run_date =run_date
        self.run_month = pd.to_datetime( self.run_date).strftime("%b%y")
        self.run_month_lower=self.run_month.lower()
        self.database=self.subtenant

        self.file_key1=f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{self.run_month}/final_model/Input/sm_site_competitors_top_10_combo_v4_Aug23.txt'
        self.path1=f's3://{self.enrich_bucket}/{self.file_key1}'    

        self.file_key2 =f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/cmp_master/{base_month}_compmaster_file.xlsx'
        self.path2=f's3://{self.enrich_bucket}/{self.file_key2}'

        self.file_key3=f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/final_model/Input/Diesel_hourly_time_slot_final.txt'
        self.path3=f's3://{self.enrich_bucket}/{self.file_key3}'

        self.file_key4=f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/final_model/Input/sc_try_best_model_diesel_all_levels.txt'
        self.path4=f's3://{self.enrich_bucket}/{self.file_key4}'
        
        self.file_key5=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/final_model/Output/offset_tbl/offset_tbl.txt000'
        self.path5=f's3://{self.enrich_bucket}/{self.file_key5}'

        self.file_key6=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/bp_master/{base_month}_master_file.xlsx'
        self.path6=f's3://{self.enrich_bucket}/{self.file_key6}'

        self.file_key7=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/final_model/Output/sheet2_ext_tble/sheet2_ext_tble.txt000'
        self.path7=f's3://{self.enrich_bucket}/{self.file_key7}'

        self.file_key81=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/Breakdown/Output_autohof/Breakdown_refreshed_autohof_Diesel.xlsx'
        self.path81=f's3://{self.enrich_bucket}/{self.file_key81}'
        self.file_key82=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/Breakdown/Output_street/Breakdown_refreshed_street_Diesel.xlsx'
        self.path82=f's3://{self.enrich_bucket}/{self.file_key82}'

        self.file_key9=  f'main/mobconv/enrich_main_mobconv_bpcis_mod/DE/AFP/{base_month}/final_model/Input/Brandmapping.xlsx'
        self.path9=f's3://{self.enrich_bucket}/{self.file_key9}'

        self.destination_object_key1 =  f'main/{self.database}/enrich_main_mobconv_bpcis_mod/DE/AFP/{self.run_month}/final_model/Output/'
        self.output_path1=f's3://{self.enrich_bucket}/{self.destination_object_key1}'

        self.destination_object_key2 =  f'main/{self.database}/enrich_main_mobconv_bpcis_mod/DE/AFP/{self.run_month}/final_model/Output_check/'
        self.output_path2=f's3://{self.enrich_bucket}/{self.destination_object_key2}'

     # Get job rub run id in python shell jobs
        run_response = self.glue_client.get_job_runs(
            JobName='mobconv-afp-mod-de-rslt-glue-pythonshell',
            MaxResults=1
        )
        JobRuns = run_response['JobRuns']
        for i in JobRuns:
            Job_id = i['Id']
            JobRunState = i['JobRunState']
        self.job_run_id = Job_id
        self.job_run_state = JobRunState
        # Log initialization

        logging.basicConfig(format='%(message)s')
        self.glue_log = GlueJsonLogFilter(
            subtenant=self.subtenant,
            pipeline=self.pipeline,
            job_run_id=self.job_run_id,
            peh_id=self.execution_id,
            kms_alias=None
        ).set_logger(self.logger)

        # Logging
        self.glue_log.info("job_run_id: " + self.job_run_id + "\n JobRunState : " + self.job_run_state)
        self.glue_log.info("subtenant: " + self.subtenant)
        self.glue_log.info("pipeline: " + self.pipeline)

        # READ YAML file
        self.yaml_data = self._parse_yaml(self.yaml_config_path)   
        # YAML file read completed
        self.main()

    @staticmethod
    def _get_glue_args(cli_args):
        glue_args = getResolvedOptions(args=sys.argv, options=cli_args)
        return glue_args


     # Method to Cleanup s3 location.
    def _dataCleanUpProcess(self, s3_path, bucket):
        try:
            self.glue_log.info("Files will be deleted from path - " + str(s3_path))
            tgt_bucket = self.s3_resource.Bucket(bucket)

            self.glue_log.info("Cleanup started")
            for obj in tgt_bucket.objects.filter(Prefix=s3_path):
                self.s3_resource.Object(tgt_bucket.name, obj.key).delete()
                print("\nDeleted file :" + str(obj.key))
            self.glue_log.info("Cleanup completed")

        except Exception as ex:
            self.glue_log.error("Error in dataCleanUpProcess() method. Error - " + str(ex))
            raise ex
            
    def _python_shell_execute(self, command):
        push = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = push.communicate()

        return stdout, stderr
    
    def _folder_exists_and_not_empty(self,bucket:str, path:str) -> bool:
        '''
        Folder should exists. 
        Folder should not be empty.
        '''
        self.glue_log.info("Inside _folder_exists_and_not_empty() ")
        print("bucket _folder_exists_and_not_empty" + bucket)
        print("path _folder_exists_and_not_empty" + path)
        
        s3 = boto3.client('s3')
        if not path.endswith('/'):
            path = path+'/' 
        resp = s3.list_objects(Bucket=bucket, Prefix=path, Delimiter='/',MaxKeys=1)
        return 'Contents' in resp
    
    # Method to copy files 
    def _write_to_s3(self, src_bucket, source_path, tgt_bucket, target_path, file_type= None):
        self.glue_log.info("Inside write_to_s3() method.")
        try:
            
            # Copying files to target location
            if self._folder_exists_and_not_empty(src_bucket, source_path):
                source_path_final = "s3://" + src_bucket + "/" + source_path
                target_path_final = "s3://" + tgt_bucket + "/" + target_path
                if file_type == None:
                    print("inside recursive")
                    self.copy_from_s3 = """aws s3 cp {0} {1} --acl bucket-owner-full-control --recursive --sse AES256 """.format(                    source_path_final, target_path_final)
                    stdout, stderr = self._python_shell_execute(self.copy_from_s3)
                    if not stderr:
                            self.glue_log.info("Copy of data files completed")
                    else:
                        self.glue_log.error("Error while copying files.")
                        print("stderr - " + str(stderr))
                        sys.exit(1)
                else:
                    s3_resource = boto3.resource('s3')
                    my_src_bucket = s3_resource.Bucket(src_bucket)
                    print(" File list path : " + target_path)
                    file_list = []
                    # list of files  with required file type. e.g : create a list of all parquet files to be copied
                    for object_summary in my_src_bucket.objects.filter(Prefix=source_path):
                        filename = str(object_summary.key)
                        if (filename.find(file_type)) != -1:
                            file_list.append(filename)
                        print("file_list :" + str(file_list))
                    for file in file_list:
                        source_path = "s3://" + src_bucket + "/" + file
                        print(" File list path : " + file)
                        self.copy_from_s3 = """aws s3 cp {0} {1} --acl bucket-owner-full-control --sse AES256 """.format(source_path, target_path_final)
                    
                        stdout, stderr = self._python_shell_execute(self.copy_from_s3)
                        if not stderr:
                            self.glue_log.info("Copy of data files completed")
                        else:
                            self.glue_log.error("Error while copying files.")
                            print("stderr - " + str(stderr))
                            sys.exit(1)
            else:
                self.glue_log.info("No object present to copy from location : " + str(source_path))
        except Exception as ex:
            self.glue_log.error("Error in _write_to_s3() method. Error - " + str(ex))
            raise ex
            

    def _get_file(self, s3_file_path):
        """
        Download file form S3 bucket
        """
        try:
            bucket, key = s3_file_path.replace("s3://", "").split("/", 1)
            obj = self.s3_client.get_object(Bucket=bucket, Key=key)
            return obj
        except Exception as ex:
            self.glue_log.error("exception in s3 read  \n" + str(ex))
            raise ex
            
    def _parse_yaml(self, path_to_config_file):
        response = self._get_file(path_to_config_file)
        try:
            return yaml.safe_load(response["Body"])
        except Exception as ex:
            self.glue_log.error("exception in yaml read")
            raise ex
          
    def _get_latest_file_s3path(self, tgt_bucket, tgt_key_prefix, file_type):
        my_bucket = s3_resource.Bucket(tgt_bucket)
        latest_timestamp = []
        file_list = []
        for object_summary in my_bucket.objects.filter(Prefix=tgt_key_prefix):
            filename = str(object_summary.key)
            if (filename.find(file_type)) != -1:
                file_list.append(filename)
                latest_timestamp.append(object_summary.last_modified)
        timestamp_and_filename = dict(zip(latest_timestamp,file_list))
        max_timestamp = p.max(set(latest_timestamp))
        latest_filename = timestamp_and_filename.get(max_timestamp)
        latest_filename = latest_filename.rsplit('/',1)
        print(latest_filename[0])
        return latest_filename[0]
        
    def _update_crawler(self, crawler_name, tgt_glue_db_name, target_bucket, tgt_s3_path):
        try:
            time_elapsed = 60
            crawler_update_status = False
            while (True) :
                response = self.glue_client.get_crawler(Name=crawler_name)
                crawler_state = response['Crawler']['State']
                self.glue_log.info("Crawler State: " + str(crawler_state))
                if crawler_state == 'READY':
                    self.glue_log.info("Crawler Update Started: " + crawler_name)
                    self.glue_client.update_crawler(
                    Name = crawler_name,
                    DatabaseName = tgt_glue_db_name,
                    Targets = 
                    {
                        'S3Targets':    
                        [
                            {
                                'Path': tgt_s3_path
                            }
                        ]
                    }
                    )
                    self.glue_log.info("Crawler Update Completed : " + crawler_name)
                    crawler_update_status = True
                    break
                else:
                    if time_elapsed < 600:
                        time.sleep(time_elapsed)
                        time_elapsed = time_elapsed + 60
                    else :
                        break
            if crawler_update_status == False:
                self.glue_log.error('Crawler update failed due to current state : ' + crawler_state )
                sys.exit(1)
            
            response = self.glue_client.get_crawler(Name=crawler_name)
            self.glue_log.info("Crawler response: " + str(response))    
            return crawler_update_status
            
        except self.glue_client.exceptions.CrawlerRunningException as ex:
            self.glue_log.error('Crawler update failed : \n' + str(ex))

    def _start_crawler(self, crawler_name):
        try:
            time_elapsed = 60
            crawler_start_status = False
            while (True) :
                response = self.glue_client.get_crawler(Name=crawler_name)
                crawler_state = response['Crawler']['State']
                self.glue_log.info("Crawler State: " + str(crawler_state))
                if crawler_state == 'READY':
                    self.glue_log.info("Crawler run Started: " + crawler_name)
                    self.glue_client.start_crawler(
                    Name = crawler_name
                    )
                    self.glue_log.info("Crawler Run Completed : " + crawler_name)
                    crawler_start_status = True
                    break 
                else:
                    if time_elapsed < 600:
                        time.sleep(time_elapsed)
                        time_elapsed = time_elapsed + 60
                    else :
                        break
            if crawler_start_status == False:
                self.glue_log.error('Crawler run failed due to current state : ' + crawler_state )
                sys.exit(1)
                
            return crawler_start_status
            
        except self.glue_client.exceptions.CrawlerRunningException as ex:
            self.glue_log.error('Crawler run failed : \n' + str(ex))

    def _delete_glue_table(self, tgt_glue_db_name, tgt_tbl_name):
        try:
            response = self.glue_client.delete_table(
                DatabaseName = tgt_glue_db_name,
                Name = tgt_tbl_name
                )
        except Exception as ex:
            self.glue_log.error("Error Table delete. Error - " + str(ex))
            raise ex 
   
    def file_reading_top10(self):
        top_10=pd.read_csv(self.path1,sep = '|')
        comp_data=pd.read_excel(self.path2,sheet_name=['comp mapping'])
        Comp_mapping_new = comp_data.get('comp mapping')
        return top_10,Comp_mapping_new

    def file_reading_wm_tslot(self):
        wm_tslot=pd.read_csv(self.path3)
        wm_tslot1 = wm_tslot[['Pkey','Competitor_elasticity','flag_day']]
        wm_tslot_pivot = pd.pivot_table(wm_tslot1, values='Competitor_elasticity', 
                                index='Pkey', 
                                columns='flag_day')
        wm_tslot_pivot = wm_tslot_pivot.fillna('')
        wm_tslot_pivot = wm_tslot_pivot.reset_index()
        wm_tslot = wm_tslot[wm_tslot. columns[:-2]]
        wm_tslot.rename({'Pkey':'Pkey1' },axis =1,inplace = True)
        return wm_tslot,wm_tslot_pivot 

    def file_reading_Str1_Dies(self):
        Str1_Dies=pd.read_csv(self.path4,sep = '|')
        Str1_Dies = Str1_Dies[['Pkey','R_squared','Level_Variance','Slope','BasePrice','Seasonality','avg_y','avg_price','price_elasticity','Active_promo','Own_promo','Other_promo','Var_List','Max_Pval_Reg','Max_Pval_Seas','Max_Pval_Pos','Max_Pval_Neg','Min_Base','Competitor_elasticity','Points_elasticity','season_ucm','levels','variables','distance','completeness_linked','cnt_competitors','competitors_Concat','X1','X2','X3','X4','X5','levels_tried','prod','num_comp','overlap_LTA','max_R_squared','max_comp','candidate_2','max_overlap_LTA','min_distance','candidate_1','max_rsq','candidate_3']]
        comp_data=pd.read_excel(self.path2,sheet_name=['comp mapping'])
        Comp_mapping_new = comp_data .get('comp mapping')
        Comp_mapping_new = Comp_mapping_new[['Competitor extended code','Competitor Code','Brand','Competitor Address']]
        Comp_mapping_new.loc[:,'Competitor extended code'] = Comp_mapping_new.loc[:,'Competitor extended code'].str.lower()
        Comp_mapping_new = Comp_mapping_new[~Comp_mapping_new['Competitor extended code'].isna()]
        return Str1_Dies,Comp_mapping_new    

    def file_reading_off_set(self):
        off_set=pd.read_csv(self.path5)
        off_set = off_set[['ownsiteid','competitorid','competitorbrand','category','wbprodukt']]
        bp_master=pd.read_excel(self.path6,sheet_name=['BP_Master'])
        bp_master = bp_master .get('BP_Master')
        bp_master.columns = bp_master.columns.str.replace('\n','')
        comp_data=pd.read_excel(self.path2,sheet_name=['comp mapping'])
        Comp_mapping_new = comp_data .get('comp mapping')
        Comp_mapping_new = Comp_mapping_new[['Competitor extended code','Competitor Code','Brand','Competitor Address']]
        return off_set,bp_master,Comp_mapping_new  

    def file_reading_final(self):
        # Read BP_Master
        bp_master=pd.read_excel(self.path6,sheet_name=['BP_Master'])
        bp_master = bp_master .get('BP_Master')
        bp_master_inscope = bp_master[bp_master['in-scope of analysis (Aug23)'] == 'yes']
        bp_master_inscope = bp_master_inscope[['alternateimportcode','Importcode','Address','City','Current Channel Of Trade','District Description (Analytics DB)','Type Final (updated from pricenet) ']]
        
        BP_master_sheet2 = pd.read_csv(self.path7)
        BP_master_sheet2.rename({'importcode': 'importcode2'}, axis=1, inplace=True)
        # read comp_master sheet name masterdata
        comp_data=pd.read_excel(self.path2,sheet_name=['Master data'])
        Comp_mapping_new_master = comp_data .get('Master data')
        # read comp_master sheet name comp mapping
        comp_data1 = pd.read_excel(self.path2,sheet_name=['comp mapping'])
        Comp_mapping_new = comp_data1 .get('comp mapping') 
        #read str1 dies
        Str1_Dies  = self.merge_data()
        # # read Diesel wm tslot data 
        wm_tslot_pivot = self.file_reading_wm_tslot()[1]
        # read std_offset
        off_set_diesel = self.reset_columns()[0]
        #read breakdown data
        Breakdown_refreshed_autohof=pd.read_excel(self.path81)
        Breakdown_refreshed_street=pd.read_excel(self.path82)
        breakdown=pd.concat([Breakdown_refreshed_autohof,Breakdown_refreshed_street])
        # read Brand Mapping
        brand_mapping=pd.read_excel(self.path9)
        return bp_master_inscope,Comp_mapping_new_master,Str1_Dies,wm_tslot_pivot,off_set_diesel,Comp_mapping_new,breakdown,brand_mapping,BP_master_sheet2
          

    def file_reading_breakdown(self):

        bp_master_inscope = self.merge_data_with_BP_master_sheet2()
        final_results_diesel = self.column_setup_final(bp_master_inscope)

        breakdown = self.file_reading_final()[6]

        final_result = final_results_diesel[['Site Code','Rank 1','Rank 2','Rank 3','Rank 4','Rank 5','Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5','Competitor 1 Brand','Competitor 2 Brand','Competitor 3 Brand','Competitor 4 Brand','Competitor 5 Brand','Competitor 1 Importance Diesel Model','Competitor 2 Importance Diesel Model','Competitor 3 Importance Diesel Model','Competitor 4 Importance Diesel Model','Competitor 5 Importance Diesel Model']]
        final_result.drop_duplicates(subset=['Site Code'], keep='first',inplace=True)
        return breakdown,final_results_diesel,final_result


    def data_setup(self):
        top_10 = self.file_reading_top10()[0]
        Comp_mapping_new = self.file_reading_top10()[1]
        top_10['key'] = top_10['external_site_ref'].astype(str) + top_10['competitorsiteuid'].astype(str)
        top_10['comp type'] = ' '
        top_10['comp type'] = np.where(((top_10['comp_autohof'] == 1.0)), 'Autohof', top_10['comp type'])
        top_10['comp type'] = np.where(((top_10['comp_motorway'] == 1.0)), 'Motorway', top_10['comp type'])
        top_10['competitorsiteuid'] = top_10['competitorsiteuid'].str.upper()
        Comp_mapping_new['Competitor extended code'] = Comp_mapping_new['Competitor extended code'].str.upper()
        return top_10,Comp_mapping_new
    
    def merge_file(self):
        top_10 = self.data_setup()[0]
        Comp_mapping_new = self.data_setup()[1]
        top_10_final = pd.merge(top_10, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='competitorsiteuid', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        top_10_final.rename(columns = {'Competitor Code':'comp id'},inplace = True)
        columns = ['key','importcode','external_site_ref','competitorsiteuid','driving_distance_meters','bp_type','name','rank','comp_motorway','comp_autohof','comp type','comp id']
        top_10_final = top_10_final[columns]
        top_10 = top_10_final[top_10_final['comp_autohof'] == 1]
        top_10 = top_10[['external_site_ref','comp id','driving_distance_meters','bp_type','comp type']]
        return top_10_final,top_10

    
    def merge_data(self):
        Str1_Dies,Comp_mapping_new = self.file_reading_Str1_Dies()
        Str1_Dies1 = pd.merge(Str1_Dies, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='X1', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        Str1_Dies1.rename({'Competitor Code': 'Comp 1'}, axis=1, inplace=True)
        
        Str1_Dies2 = pd.merge(Str1_Dies1, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='X2', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        Str1_Dies2.rename({'Competitor Code': 'Comp 2'}, axis=1, inplace=True)
        Str1_Dies3 = pd.merge(Str1_Dies2, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='X3', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        Str1_Dies3.rename({'Competitor Code': 'Comp 3'}, axis=1, inplace=True)
        Str1_Dies4 = pd.merge(Str1_Dies3, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='X4', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        Str1_Dies4.rename({'Competitor Code': 'Comp 4'}, axis=1, inplace=True)
        Str1_Dies5 = pd.merge(Str1_Dies4, Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='X5', right_on='Competitor extended code', how='left').drop('Competitor extended code', axis=1)
        Str1_Dies5.rename({'Competitor Code': 'Comp 5'}, axis=1, inplace=True)
        Str1_Dies6 = Str1_Dies5.join(Str1_Dies5[['Comp 1','Comp 2','Comp 3','Comp 4','Comp 5']].rank(axis = 1).add_suffix("_rank"))
        Str1_Dies = Str1_Dies6.fillna(0)
        Str1_Dies['Competitor 1'] = np.where((Str1_Dies['Comp 1_rank']==1),Str1_Dies['Comp 1'],np.where((Str1_Dies['Comp 2_rank']==1),Str1_Dies['Comp 2'],np.where((Str1_Dies['Comp 3_rank']==1),Str1_Dies['Comp 3'],np.where((Str1_Dies['Comp 4_rank']==1),Str1_Dies['Comp 4'],np.where((Str1_Dies['Comp 5_rank']==1),Str1_Dies['Comp 5'],'na')))))
        Str1_Dies['Competitor 2'] = np.where((Str1_Dies['Comp 1_rank']==2),Str1_Dies['Comp 1'],np.where((Str1_Dies['Comp 2_rank']==2),Str1_Dies['Comp 2'],np.where((Str1_Dies['Comp 3_rank']==2),Str1_Dies['Comp 3'],np.where((Str1_Dies['Comp 4_rank']==2),Str1_Dies['Comp 4'],np.where((Str1_Dies['Comp 5_rank']==2),Str1_Dies['Comp 5'],'na')))))
        Str1_Dies['Competitor 3'] = np.where((Str1_Dies['Comp 1_rank']==3),Str1_Dies['Comp 1'],np.where((Str1_Dies['Comp 2_rank']==3),Str1_Dies['Comp 2'],np.where((Str1_Dies['Comp 3_rank']==3),Str1_Dies['Comp 3'],np.where((Str1_Dies['Comp 4_rank']==3),Str1_Dies['Comp 4'],np.where((Str1_Dies['Comp 5_rank']==3),Str1_Dies['Comp 5'],'na')))))
        Str1_Dies['Competitor 4'] = np.where((Str1_Dies['Comp 1_rank']==4),Str1_Dies['Comp 1'],np.where((Str1_Dies['Comp 2_rank']==4),Str1_Dies['Comp 2'],np.where((Str1_Dies['Comp 3_rank']==4),Str1_Dies['Comp 3'],np.where((Str1_Dies['Comp 4_rank']==4),Str1_Dies['Comp 4'],np.where((Str1_Dies['Comp 5_rank']==4),Str1_Dies['Comp 5'],'na')))))
        Str1_Dies['Competitor 5'] = np.where((Str1_Dies['Comp 1_rank']==5),Str1_Dies['Comp 1'],np.where((Str1_Dies['Comp 2_rank']==5),Str1_Dies['Comp 2'],np.where((Str1_Dies['Comp 3_rank']==5),Str1_Dies['Comp 3'],np.where((Str1_Dies['Comp 4_rank']==5),Str1_Dies['Comp 4'],np.where((Str1_Dies['Comp 5_rank']==5),Str1_Dies['Comp 5'],'na')))))
        Str1_Dies['Run'] = 1
        Str1_Dies['Point_Contrib'] = ' '
        Str1_Dies.rename({'Comp 1_rank': 'Rank comp 1','Comp 2_rank': 'Rank comp 2','Comp 3_rank': 'Rank comp 3','Comp 4_rank': 'Rank comp 4','Comp 5_rank': 'Rank comp 5'}, axis=1, inplace=True)
        return Str1_Dies

    def data_setup_off_set(self):
        off_set = self.file_reading_off_set()[0]
        sorted_off_set = off_set.sort_values(by=['ownsiteid','category'] ,ascending=True)
        off_set_diesel = sorted_off_set[sorted_off_set['wbprodukt'] == 'Super Diesel SB']
        super = ['Super E10 SB', 'Super E5 SB']
        off_set_super = sorted_off_set[sorted_off_set['wbprodukt'].isin(super)]
        return sorted_off_set,off_set_diesel,off_set_super    

    def merge_data_offset(self,df):
        #off_set_diesel = self.data_setup_off_set()[1]
        bp_master = self.file_reading_off_set()[1]
        Comp_mapping_new = self.file_reading_off_set()[2]
        #mapped with BP Master
        df1 =  pd.merge(df,bp_master[['Importcode','alternateimportcode']], left_on='ownsiteid', right_on='Importcode', how='left').drop('Importcode', axis=1)
        #mapped with comp master
        df1 =  pd.merge(df1,Comp_mapping_new[['Competitor extended code','Competitor Code']], left_on='competitorid', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        # keep the required column 
        df1_final = df1[['alternateimportcode','ownsiteid','competitorid','Competitor extended code','competitorbrand']]
        return df1_final

    
    def add_count_column(self,df):
        # Create a new column 'Count' with default value 0
        df['Cnt'] = 0
        # Dictionary to store counts of unique rows
        counts = {}
        # Iterate through the DataFrame and update the 'Count' column
        for index, row in df[['ownsiteid']].iterrows():
            row_tuple = tuple(row)
            if row_tuple in counts:
                counts[row_tuple] += 1
            else:
                counts[row_tuple] = 1
            df.at[index, 'Cnt'] = counts[row_tuple]
        return df
    
    def add_count(self):
        df1,df2,df3 = self.data_setup_off_set()
        off_set_diesel1_final = self.merge_data_offset(df2)
        off_set_diesel1_final = self.add_count_column(off_set_diesel1_final)
        off_set_diesel1_final['key']  = off_set_diesel1_final['ownsiteid'] + '' + off_set_diesel1_final['Cnt'].astype(str)
        off_set_diesel1_final.rename(columns={'alternateimportcode': 'BP site', 'ownsiteid': 'Site code','competitorid': 'Competitor extended code','Competitor extended code': 'Competitor code'}, inplace=True)
        off_set_super1_final = self.merge_data_offset(df3)
        off_set_super1_final = self.add_count_column(off_set_super1_final)
        off_set_super1_final['key']  = off_set_super1_final['ownsiteid'] + '' + off_set_super1_final['Cnt'].astype(str)
        off_set_super1_final.rename(columns={'alternateimportcode': 'BP site', 'ownsiteid': 'Site code','competitorid': 'Competitor extended code','Competitor extended code': 'Competitor code'}, inplace=True)
        return off_set_diesel1_final,off_set_super1_final
    
    def reset_columns(self):
        off_set_diesel1_final,off_set_super1_final =  self.add_count()
        columns = ['key','BP site','Site code','Competitor extended code','Competitor code','competitorbrand','Cnt']
        off_set_diesel1_final = off_set_diesel1_final[columns]
        off_set_super1_final = off_set_super1_final[columns]
        return off_set_diesel1_final,off_set_super1_final

    def merge_data_with_str1_dies(self):        
        bp_master_inscope = self.file_reading_final()[0]
        Comp_mapping_new_master = self.file_reading_final()[1]
        Str1_Dies = self.file_reading_final()[2]
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies[['Pkey','Competitor_elasticity']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope.rename({'Competitor_elasticity': 'Diesel Elasticity Model'}, axis=1, inplace=True)
        bp_master_inscope["Diesel District Elasticity"]=bp_master_inscope.groupby(['District Description (Analytics DB)'])['Diesel Elasticity Model'].transform('mean')
        bp_master_inscope['Final Diesel Elasticity'] = np.where(bp_master_inscope['Diesel Elasticity Model'].isna(),bp_master_inscope['Diesel District Elasticity'],bp_master_inscope['Diesel Elasticity Model'])
        bp_master_inscope['Elasticity source'] = np.where(bp_master_inscope['Diesel Elasticity Model'].isna(),'District','MOD-D')
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies[['Pkey','R_squared']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['R_squared'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['R_squared'],'')
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies[['Pkey','levels_tried']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['levels_tried'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['levels_tried'],'')
        return bp_master_inscope  

    def merge_data_with_wm_tslot_pivot(self):
        bp_master_inscope = self.merge_data_with_str1_dies()
        wm_tslot_pivot = self.file_reading_final()[3]
        bp_master_inscope = pd.merge(bp_master_inscope, wm_tslot_pivot[['Pkey','Diesel_morning']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope.rename({'Diesel_morning': 'Diesel (04:00-10:00) Elasticity'}, axis=1, inplace=True)
        bp_master_inscope = pd.merge(bp_master_inscope, wm_tslot_pivot[['Pkey','Diesel_noon']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope.rename({'Diesel_noon': 'Diesel (10:00-13:00) Elasticity'}, axis=1, inplace=True)
        bp_master_inscope = pd.merge(bp_master_inscope, wm_tslot_pivot[['Pkey','Diesel_afternoon']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope.rename({'Diesel_afternoon': 'Diesel (13:00-16:00) Elasticity'}, axis=1, inplace=True)
        bp_master_inscope = pd.merge(bp_master_inscope, wm_tslot_pivot[['Pkey','Diesel_evening']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope.rename({'Diesel_evening': 'Diesel (16:00-22:00) Elasticity'}, axis=1, inplace=True)
        bp_master_inscope['Diesel (04:00-10:00) Elasticity'] = pd.to_numeric(bp_master_inscope['Diesel (04:00-10:00) Elasticity'])
        bp_master_inscope['Diesel (10:00-13:00) Elasticity'] = pd.to_numeric(bp_master_inscope['Diesel (10:00-13:00) Elasticity'])
        bp_master_inscope['Diesel (13:00-16:00) Elasticity'] = pd.to_numeric(bp_master_inscope['Diesel (13:00-16:00) Elasticity'])
        bp_master_inscope['Diesel (16:00-22:00) Elasticity'] = pd.to_numeric(bp_master_inscope['Diesel (16:00-22:00) Elasticity'])        
        bp_master_inscope['Diesel (04:00-10:00) Elasticity District'] =  bp_master_inscope.groupby(['District Description (Analytics DB)'])['Diesel (04:00-10:00) Elasticity'].transform('mean')
        bp_master_inscope['Diesel (10:00-13:00) Elasticity District'] =  bp_master_inscope.groupby(['District Description (Analytics DB)'])['Diesel (10:00-13:00) Elasticity'].transform('mean')
        bp_master_inscope['Diesel (13:00-16:00) Elasticity District'] =  bp_master_inscope.groupby(['District Description (Analytics DB)'])['Diesel (13:00-16:00) Elasticity'].transform('mean')
        bp_master_inscope['Diesel (16:00-22:00) Elasticity District'] =  bp_master_inscope.groupby(['District Description (Analytics DB)'])['Diesel (16:00-22:00) Elasticity'].transform('mean')
        bp_master_inscope['Final Diesel (04:00-10:00) Elasticity'] = np.where(bp_master_inscope['Diesel (04:00-10:00) Elasticity'].isna(),bp_master_inscope['Diesel (04:00-10:00) Elasticity District'],bp_master_inscope['Diesel (04:00-10:00) Elasticity'])
        bp_master_inscope['Final Diesel (10:00-13:00) Elasticity'] = np.where(bp_master_inscope['Diesel (10:00-13:00) Elasticity'].isna(),bp_master_inscope['Diesel (10:00-13:00) Elasticity District'],bp_master_inscope['Diesel (10:00-13:00) Elasticity'])
        bp_master_inscope['Final Diesel (13:00-16:00) Elasticity'] = np.where(bp_master_inscope['Diesel (13:00-16:00) Elasticity'].isna(),bp_master_inscope['Diesel (13:00-16:00) Elasticity District'],bp_master_inscope['Diesel (13:00-16:00) Elasticity'])
        bp_master_inscope['Final Diesel (16:00-22:00) Elasticity'] = np.where(bp_master_inscope['Diesel (16:00-22:00) Elasticity'].isna(),bp_master_inscope['Diesel (16:00-22:00) Elasticity District'],bp_master_inscope['Diesel (16:00-22:00) Elasticity'])
        return bp_master_inscope      
    
    def merge_data_with_off_set_diesel(self):
        bp_master_inscope = self.merge_data_with_wm_tslot_pivot()
        off_set_diesel = self.file_reading_final()[4]
        off_set_diesel1 = off_set_diesel[['Site code','Competitor extended code','Cnt']]
        off_set_diesel1 = pd.pivot_table(off_set_diesel1, values='Competitor extended code', index='Site code', columns='Cnt')
        off_set_diesel1.reset_index(inplace=True)
        off_set_diesel1.rename({1: 'Linked Competitor 1',2: 'Linked Competitor 2',3: 'Linked Competitor 3',4: 'Linked Competitor 4',5: 'Linked Competitor 5',6: 'Linked Competitor 6'}, axis=1, inplace=True)
        bp_master_inscope = pd.merge(bp_master_inscope, off_set_diesel1[['Site code','Linked Competitor 1']], left_on='Importcode', right_on='Site code', how='left').drop('Site code', axis=1)
        bp_master_inscope = pd.merge(bp_master_inscope, off_set_diesel1[['Site code','Linked Competitor 2']], left_on='Importcode', right_on='Site code', how='left').drop('Site code', axis=1)
        bp_master_inscope = pd.merge(bp_master_inscope, off_set_diesel1[['Site code','Linked Competitor 3']], left_on='Importcode', right_on='Site code', how='left').drop('Site code', axis=1)
        bp_master_inscope = pd.merge(bp_master_inscope, off_set_diesel1[['Site code','Linked Competitor 4']], left_on='Importcode', right_on='Site code', how='left').drop('Site code', axis=1)
        bp_master_inscope = pd.merge(bp_master_inscope, off_set_diesel1[['Site code','Linked Competitor 5']], left_on='Importcode', right_on='Site code', how='left').drop('Site code', axis=1)
        bp_master_inscope['Linked Competitor 1'] = bp_master_inscope['Linked Competitor 1'].replace(np.nan, '')
        bp_master_inscope['Linked Competitor 2'] = bp_master_inscope['Linked Competitor 2'].replace(np.nan, '')
        bp_master_inscope['Linked Competitor 3'] = bp_master_inscope['Linked Competitor 3'].replace(np.nan, '')
        bp_master_inscope['Linked Competitor 4'] = bp_master_inscope['Linked Competitor 4'].replace(np.nan, '')
        bp_master_inscope['Linked Competitor 5'] = bp_master_inscope['Linked Competitor 5'].replace(np.nan, '')
        bp_master_inscope['Linked'] = bp_master_inscope['Linked Competitor 1'].map(str) + '/' + bp_master_inscope['Linked Competitor 2'].map(str)+ '/' + bp_master_inscope['Linked Competitor 3'].map(str)+ '/' + bp_master_inscope['Linked Competitor 4'].map(str)+ '/' + bp_master_inscope['Linked Competitor 5'].map(str)
        bp_master_inscope['Linked'] = bp_master_inscope['Linked'].replace('//','/',regex = True)
        return bp_master_inscope
    
    def merge_data_with_str1_dies2(self):
        bp_master_inscope = self.merge_data_with_off_set_diesel()
        Str1_Dies = self.file_reading_final()[2]
        Str1_Dies1 =Str1_Dies[['Pkey','Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5']]
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies1[['Pkey','Competitor 1']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['Competitor 1'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['Competitor 1'],'')
        bp_master_inscope['Competitor 1'] = np.where(bp_master_inscope['Elasticity source'] == 'District',bp_master_inscope['Linked Competitor 1'],bp_master_inscope['Competitor 1'])        
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies1[['Pkey','Competitor 2']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['Competitor 2'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['Competitor 2'],'')
        bp_master_inscope['Competitor 2'] = np.where(bp_master_inscope['Elasticity source'] == 'District',bp_master_inscope['Linked Competitor 2'],bp_master_inscope['Competitor 2'])        
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies1[['Pkey','Competitor 3']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['Competitor 3'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['Competitor 3'],'')
        bp_master_inscope['Competitor 3'] = np.where(bp_master_inscope['Elasticity source'] == 'District',bp_master_inscope['Linked Competitor 3'],bp_master_inscope['Competitor 3'])
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies1[['Pkey','Competitor 4']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['Competitor 4'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['Competitor 4'],'')
        bp_master_inscope['Competitor 4'] = np.where(bp_master_inscope['Elasticity source'] == 'District',bp_master_inscope['Linked Competitor 4'],bp_master_inscope['Competitor 4'])
        bp_master_inscope = pd.merge(bp_master_inscope, Str1_Dies1[['Pkey','Competitor 5']], left_on='alternateimportcode', right_on='Pkey', how='left').drop('Pkey', axis=1)
        bp_master_inscope['Competitor 5'] = np.where(bp_master_inscope['Elasticity source'] == 'MOD-D',bp_master_inscope['Competitor 5'],'')
        bp_master_inscope['Competitor 5'] = np.where(bp_master_inscope['Elasticity source'] == 'District',bp_master_inscope['Linked Competitor 5'],bp_master_inscope['Competitor 5'])
        bp_master_inscope['Competitor 1'] = bp_master_inscope['Competitor 1'].replace(['na'], '')
        bp_master_inscope['Competitor 2'] = bp_master_inscope['Competitor 2'].replace(['na'], '')
        bp_master_inscope['Competitor 3'] = bp_master_inscope['Competitor 3'].replace(['na'], '')
        bp_master_inscope['Competitor 4'] = bp_master_inscope['Competitor 4'].replace(['na'], '')
        bp_master_inscope['Competitor 5'] = bp_master_inscope['Competitor 5'].replace(['na'], '')
        bp_master_inscope['Competitor 1'] = pd. to_numeric(bp_master_inscope['Competitor 1']) 
        bp_master_inscope['Competitor 2'] = pd. to_numeric(bp_master_inscope['Competitor 2']) 
        bp_master_inscope['Competitor 3'] = pd. to_numeric(bp_master_inscope['Competitor 3']) 
        bp_master_inscope['Competitor 4'] = pd. to_numeric(bp_master_inscope['Competitor 4']) 
        bp_master_inscope['Competitor 5'] = pd. to_numeric(bp_master_inscope['Competitor 5']) 
        return bp_master_inscope
    
    def merge_with_comp_mapping(self):
        bp_master_inscope = self.merge_data_with_str1_dies2()
        Comp_mapping_new = self.file_reading_final()[5]
        Comp_mapping_new = Comp_mapping_new[['Competitor extended code','Competitor Code','Brand','Competitor Address']]
        Comp_mapping_new = Comp_mapping_new[Comp_mapping_new['Competitor Code'].notnull()]
        bp_master_inscope = pd.merge(bp_master_inscope, Comp_mapping_new[['Competitor Code','Brand']], left_on='Competitor 1', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        bp_master_inscope.rename({'Brand':'Competitor 1 Brand' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope, Comp_mapping_new[['Competitor Code','Brand']], left_on='Competitor 2', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        bp_master_inscope.rename({'Brand':'Competitor 2 Brand' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope, Comp_mapping_new[['Competitor Code','Brand']], left_on='Competitor 3', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        bp_master_inscope.rename({'Brand':'Competitor 3 Brand' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope, Comp_mapping_new[['Competitor Code','Brand']], left_on='Competitor 4', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        bp_master_inscope.rename({'Brand':'Competitor 4 Brand' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope, Comp_mapping_new[['Competitor Code','Brand']], left_on='Competitor 5', right_on='Competitor Code', how='left').drop('Competitor Code', axis=1)
        bp_master_inscope.rename({'Brand':'Competitor 5 Brand' },axis =1,inplace = True)
        return bp_master_inscope

    def merge_with_breakdown(self):
        bp_master_inscope = self.merge_with_comp_mapping()
        bp_master_inscope['alternateimportcode'] = bp_master_inscope['alternateimportcode'].astype(int)
        bp_master_inscope['Competitor 1'] = bp_master_inscope['Competitor 1'].astype(int)
        bp_master_inscope['import_comp1'] = bp_master_inscope['alternateimportcode'].astype(str)+'_'+ bp_master_inscope['Competitor 1'].astype(str)
        bp_master_inscope['count'] = bp_master_inscope[['Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5']].count(axis='columns')
        breakdown = self.file_reading_final()[6]
        breakdown['Competitor Code'] = breakdown['Competitor Code'].astype(int)
        breakdown['site_competitor'] = breakdown['external_site_ref'].astype(str)+'_'+breakdown['Competitor Code'].astype(str)
        bp_master_inscope = pd.merge(bp_master_inscope, breakdown[['site_competitor','comp_contr']], left_on='import_comp1', right_on='site_competitor', how='left').drop('site_competitor', axis=1)
        bp_master_inscope.rename({'comp_contr':'Competitor 1 Importance Diesel Model' },axis =1,inplace = True)
        bp_master_inscope['Competitor 2'] = bp_master_inscope['Competitor 2'].fillna(0)
        bp_master_inscope['Competitor 2'] = bp_master_inscope['Competitor 2'].astype(int)
        bp_master_inscope['import_comp2'] = bp_master_inscope['alternateimportcode'].astype(str)+'_'+ bp_master_inscope['Competitor 2'].astype(str)
        bp_master_inscope = pd.merge(bp_master_inscope, breakdown[['site_competitor','comp_contr']], left_on='import_comp2', right_on='site_competitor', how='left').drop('site_competitor', axis=1)
        bp_master_inscope.rename({'comp_contr':'Competitor 2 Importance Diesel Model' },axis =1,inplace = True)
        bp_master_inscope['Competitor 3'] = bp_master_inscope['Competitor 3'].fillna(0)
        bp_master_inscope['Competitor 3'] = bp_master_inscope['Competitor 3'].astype(int)
        bp_master_inscope['import_comp3'] = bp_master_inscope['alternateimportcode'].astype(str)+'_'+ bp_master_inscope['Competitor 3'].astype(str)
        bp_master_inscope = pd.merge(bp_master_inscope, breakdown[['site_competitor','comp_contr']], left_on='import_comp3', right_on='site_competitor', how='left').drop('site_competitor', axis=1)
        bp_master_inscope.rename({'comp_contr':'Competitor 3 Importance Diesel Model' },axis =1,inplace = True)
        bp_master_inscope['Competitor 4'] = bp_master_inscope['Competitor 4'].fillna(0)
        bp_master_inscope['Competitor 4'] = bp_master_inscope['Competitor 4'].astype(int)
        bp_master_inscope['import_comp4'] = bp_master_inscope['alternateimportcode'].astype(str)+'_'+ bp_master_inscope['Competitor 4'].astype(str)
        bp_master_inscope = pd.merge(bp_master_inscope, breakdown[['site_competitor','comp_contr']], left_on='import_comp4', right_on='site_competitor', how='left').drop('site_competitor', axis=1)
        bp_master_inscope.rename({'comp_contr':'Competitor 4 Importance Diesel Model' },axis =1,inplace = True)
        bp_master_inscope['Competitor 5'] = bp_master_inscope['Competitor 5'].fillna(0)
        bp_master_inscope['Competitor 5'] = bp_master_inscope['Competitor 5'].astype(int)
        bp_master_inscope['import_comp5'] = bp_master_inscope['alternateimportcode'].astype(str)+'_'+ bp_master_inscope['Competitor 5'].astype(str)
        bp_master_inscope = pd.merge(bp_master_inscope, breakdown[['site_competitor','comp_contr']], left_on='import_comp5', right_on='site_competitor', how='left').drop('site_competitor', axis=1)
        bp_master_inscope.rename({'comp_contr':'Competitor 5 Importance Diesel Model' },axis =1,inplace = True)
        bp_master_inscope = bp_master_inscope.drop(['import_comp1', 'import_comp2', 'import_comp3', 'import_comp4', 'import_comp5'], axis=1)
        return bp_master_inscope 

    def merge_with_breakdown2(self):
        bp_master_inscope = self.merge_with_breakdown()
        for i in range(bp_master_inscope.shape[0]):
            for j in range(1,bp_master_inscope['count'].iloc[i]+1):
                bp_master_inscope['Competitor '+str(j)+' Importance Diesel Model'].iloc[i] = np.where((bp_master_inscope['Elasticity source'].iloc[i] == 'District'),100/bp_master_inscope['count'].iloc[i]/100,bp_master_inscope['Competitor '+str(j)+' Importance Diesel Model'].iloc[i])
        return bp_master_inscope
    
    def merge_with_breakdown2_setup(self):
        bp_master_inscope = self.merge_with_breakdown2()
        bp_master_inscope['Competitor 1 Importance Diesel Model'] = bp_master_inscope['Competitor 1 Importance Diesel Model'].replace(['nan'], '0')
        bp_master_inscope['Competitor 1 Importance Diesel Model'] = bp_master_inscope['Competitor 1 Importance Diesel Model'].astype(float)
        bp_master_inscope['Competitor 2 Importance Diesel Model'] = bp_master_inscope['Competitor 2 Importance Diesel Model'].replace([''], '0')
        bp_master_inscope['Competitor 2 Importance Diesel Model'] = bp_master_inscope['Competitor 2 Importance Diesel Model'].replace(['nan'], '0')
        bp_master_inscope['Competitor 2 Importance Diesel Model'] = bp_master_inscope['Competitor 2 Importance Diesel Model'].astype(float)
        bp_master_inscope['Competitor 3 Importance Diesel Model'] = bp_master_inscope['Competitor 3 Importance Diesel Model'].replace([''], '0')
        bp_master_inscope['Competitor 3 Importance Diesel Model'] = bp_master_inscope['Competitor 3 Importance Diesel Model'].replace(['nan'], '0')
        bp_master_inscope['Competitor 3 Importance Diesel Model'] = bp_master_inscope['Competitor 3 Importance Diesel Model'].astype(float)
        bp_master_inscope['Competitor 4 Importance Diesel Model'] = bp_master_inscope['Competitor 4 Importance Diesel Model'].replace([''], '0')
        bp_master_inscope['Competitor 4 Importance Diesel Model'] = bp_master_inscope['Competitor 4 Importance Diesel Model'].replace(['nan'], '0')
        bp_master_inscope['Competitor 4 Importance Diesel Model'] = bp_master_inscope['Competitor 4 Importance Diesel Model'].astype(float)
        bp_master_inscope['Competitor 5 Importance Diesel Model'] = bp_master_inscope['Competitor 5 Importance Diesel Model'].replace([''], '0')
        bp_master_inscope['Competitor 5 Importance Diesel Model'] = bp_master_inscope['Competitor 5 Importance Diesel Model'].replace(['nan'], '0')
        bp_master_inscope['Competitor 5 Importance Diesel Model'] = bp_master_inscope['Competitor 5 Importance Diesel Model'].astype(float)
        bp_master_inscope['Competitor 1 Importance Diesel Model'] = pd.to_numeric(bp_master_inscope['Competitor 1 Importance Diesel Model'], errors='coerce').fillna(0).astype(float)
        bp_master_inscope['Competitor 2 Importance Diesel Model'] = pd.to_numeric(bp_master_inscope['Competitor 2 Importance Diesel Model'], errors='coerce').fillna(0).astype(float)
        bp_master_inscope['Competitor 3 Importance Diesel Model'] = pd.to_numeric(bp_master_inscope['Competitor 3 Importance Diesel Model'], errors='coerce').fillna(0).astype(float)
        bp_master_inscope['Competitor 4 Importance Diesel Model'] = pd.to_numeric(bp_master_inscope['Competitor 4 Importance Diesel Model'], errors='coerce').fillna(0).astype(float)
        bp_master_inscope['Competitor 5 Importance Diesel Model'] = pd.to_numeric(bp_master_inscope['Competitor 5 Importance Diesel Model'], errors='coerce').fillna(0).astype(float)
        bp_master_inscope['Sum'] = bp_master_inscope['Competitor 1 Importance Diesel Model'] + bp_master_inscope['Competitor 2 Importance Diesel Model'] + bp_master_inscope['Competitor 3 Importance Diesel Model'] + bp_master_inscope['Competitor 4 Importance Diesel Model'] + bp_master_inscope['Competitor 5 Importance Diesel Model']
        return bp_master_inscope   

    def merge_with_brand_mapping(self):
        bp_master_inscope = self.merge_with_breakdown2_setup()
        brand_mapping = self.file_reading_final()[7]
        bp_master_inscope = pd.merge(bp_master_inscope,brand_mapping,left_on = 'Competitor 1 Brand',right_on = 'All Brands',how='left').drop('All Brands', axis=1)
        bp_master_inscope.rename({'A/B Brand':'brand 1' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope,brand_mapping,left_on = 'Competitor 2 Brand',right_on = 'All Brands',how='left').drop('All Brands', axis=1)
        bp_master_inscope.rename({'A/B Brand':'brand 2' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope,brand_mapping,left_on = 'Competitor 3 Brand',right_on = 'All Brands',how='left').drop('All Brands', axis=1)
        bp_master_inscope.rename({'A/B Brand':'brand 3' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope,brand_mapping,left_on = 'Competitor 4 Brand',right_on = 'All Brands',how='left').drop('All Brands', axis=1)
        bp_master_inscope.rename({'A/B Brand':'brand 4' },axis =1,inplace = True)
        bp_master_inscope = pd.merge(bp_master_inscope,brand_mapping,left_on = 'Competitor 5 Brand',right_on = 'All Brands',how='left').drop('All Brands', axis=1)
        bp_master_inscope.rename({'A/B Brand':'brand 5' },axis =1,inplace = True)
        bp_master_inscope['A brand'] = len(bp_master_inscope[(bp_master_inscope['Competitor 1 Importance Diesel Model'] == '=A') & (bp_master_inscope['Competitor 2 Importance Diesel Model'] == '=A') & (bp_master_inscope['Competitor 3 Importance Diesel Model'] == '=A') & (bp_master_inscope['Competitor 4 Importance Diesel Model'] == '=A') & (bp_master_inscope['Competitor 5 Importance Diesel Model'] == '=A')])
        bp_master_inscope['B brand'] = len(bp_master_inscope[(bp_master_inscope['Competitor 1 Importance Diesel Model'] == '=B') & (bp_master_inscope['Competitor 2 Importance Diesel Model'] == '=B') & (bp_master_inscope['Competitor 3 Importance Diesel Model'] == '=B') & (bp_master_inscope['Competitor 4 Importance Diesel Model'] == '=B') & (bp_master_inscope['Competitor 5 Importance Diesel Model'] == '=B')])
        bp_master_inscope['Average 1'] = bp_master_inscope['Competitor 1 Importance Diesel Model'].copy()
        bp_master_inscope['Average 2'] = bp_master_inscope['Competitor 2 Importance Diesel Model'].copy()
        bp_master_inscope['Average 3'] = bp_master_inscope['Competitor 3 Importance Diesel Model'].copy()
        bp_master_inscope['Average 4'] = bp_master_inscope['Competitor 4 Importance Diesel Model'].copy()
        bp_master_inscope['Average 5'] = bp_master_inscope['Competitor 5 Importance Diesel Model'].copy()
        bp_master_inscope['Average 1'] = bp_master_inscope['Average 1'].replace(['0'], 'na')
        bp_master_inscope['Average 2'] = bp_master_inscope['Average 2'].replace(['0'], 'na')
        bp_master_inscope['Average 3'] = bp_master_inscope['Average 3'].replace(['0'], 'na')
        bp_master_inscope['Average 4'] = bp_master_inscope['Average 4'].replace(['0'], 'na')
        bp_master_inscope['Average 5'] = bp_master_inscope['Average 5'].replace(['0'], 'na')
        bp_master_inscope['Average 1'] = bp_master_inscope['Average 1'].replace(0, np.nan)
        bp_master_inscope['Average 2'] = bp_master_inscope['Average 2'].replace(0, np.nan)
        bp_master_inscope['Average 3'] = bp_master_inscope['Average 3'].replace(0, np.nan)
        bp_master_inscope['Average 4'] = bp_master_inscope['Average 4'].replace(0, np.nan)
        bp_master_inscope['Average 5'] = bp_master_inscope['Average 5'].replace(0, np.nan)
        bp_master_inscope = bp_master_inscope.join(bp_master_inscope[['Average 1','Average 2','Average 3','Average 4','Average 5']].rank(axis = 1,ascending = False).add_suffix("_rank"))
        bp_master_inscope['Average 1'] = bp_master_inscope['Average 1'].apply(lambda x: '{:.0%}'.format(x))
        bp_master_inscope['Average 2'] = bp_master_inscope['Average 2'].apply(lambda x: '{:.0%}'.format(x))
        bp_master_inscope['Average 3'] = bp_master_inscope['Average 3'].apply(lambda x: '{:.0%}'.format(x))
        bp_master_inscope['Average 4'] = bp_master_inscope['Average 4'].apply(lambda x: '{:.0%}'.format(x))
        bp_master_inscope['Average 5'] = bp_master_inscope['Average 5'].apply(lambda x: '{:.0%}'.format(x)) 
        bp_master_inscope['Average 1'] = bp_master_inscope['Average 1'].replace('nan%', '')
        bp_master_inscope['Average 2'] = bp_master_inscope['Average 2'].replace('nan%', '')
        bp_master_inscope['Average 3'] = bp_master_inscope['Average 3'].replace('nan%', '')
        bp_master_inscope['Average 4'] = bp_master_inscope['Average 4'].replace('nan%', '')
        bp_master_inscope['Average 5'] = bp_master_inscope['Average 5'].replace('nan%', '')
        bp_master_inscope.rename({'Average 1_rank':'Rank 1','Average 2_rank':'Rank 2','Average 3_rank':'Rank 3','Average 4_rank':'Rank 4','Average 5_rank':'Rank 5' },axis =1,inplace = True)
        return bp_master_inscope   

    def merge_data_with_BP_master_sheet2(self):
        BP_master_sheet2 = self.file_reading_final()[8]
        bp_master_inscope = self.merge_with_brand_mapping()
        bp_master_inscope = pd.merge(bp_master_inscope,BP_master_sheet2, left_on='Importcode', right_on='importcode2', how='left').drop('importcode2', axis=1)
        return bp_master_inscope

    def corel(self,df1):
        a = 0.33
        b = 0.17
        df1['D correl']  = 'NaN'
        df1['D correl'] = df1['Final Diesel (04:00-10:00) Elasticity']*a + df1['Final Diesel (10:00-13:00) Elasticity']*b+df1['Final Diesel (13:00-16:00) Elasticity']*b+df1['Final Diesel (16:00-22:00) Elasticity']*a 
        return df1

    def column_setup_final(self,df1):
        bp_master_inscope = self.merge_data_with_BP_master_sheet2()
        final_data = self.corel(bp_master_inscope)
        columns = ['alternateimportcode', 'Importcode', 'Address','postcode','City', 'Current Channel Of Trade',  'omr_region','District Description (Analytics DB)',
       'Type Final (updated from pricenet) ', 'Diesel Elasticity Model','Diesel District Elasticity', 'Final Diesel Elasticity','Elasticity source', 'R_squared', 'levels_tried','D correl',
       'Diesel (04:00-10:00) Elasticity', 'Diesel (10:00-13:00) Elasticity','Diesel (13:00-16:00) Elasticity', 'Diesel (16:00-22:00) Elasticity','Diesel (04:00-10:00) Elasticity District',
       'Diesel (10:00-13:00) Elasticity District','Diesel (13:00-16:00) Elasticity District','Diesel (16:00-22:00) Elasticity District','Final Diesel (04:00-10:00) Elasticity',
       'Final Diesel (10:00-13:00) Elasticity','Final Diesel (13:00-16:00) Elasticity','Final Diesel (16:00-22:00) Elasticity','Competitor 1', 'Competitor 2','Competitor 3', 'Competitor 4', 'Competitor 5',
        'Competitor 1 Brand','Competitor 2 Brand', 'Competitor 3 Brand', 'Competitor 4 Brand','Competitor 5 Brand','Competitor 1 Importance Diesel Model','Competitor 2 Importance Diesel Model','Competitor 3 Importance Diesel Model','Competitor 4 Importance Diesel Model','Competitor 5 Importance Diesel Model',
        'Sum','count','Linked Competitor 1','Linked Competitor 2', 'Linked Competitor 3', 'Linked Competitor 4','Linked Competitor 5', 'Linked', 'brand 1', 'brand 2','brand 3', 'brand 4', 'brand 5', 'A brand', 'B brand', 
        'Average 1','Average 2', 'Average 3', 'Average 4', 'Average 5', 'Rank 1', 'Rank 2','Rank 3', 'Rank 4', 'Rank 5']
        Final_Results_Diesel1 =  final_data[columns]
        Final_Results_Diesel1.rename({'alternateimportcode':'BP Site','Importcode':'Site Code','Address':'Site Address','postcode':'Site Postcode','City':'Site City','Current Channel Of Trade':'Channel of Trade (COT)','omr_region':'Region','District Description (Analytics DB)':'District','Type Final (updated from pricenet) ':'Type','Sum':'Sum importance Diesel','count':'Count new competitor' },axis =1,inplace = True)
        return Final_Results_Diesel1    
                

    def data_setup_sheet1(self,final_result):
        Rank = pd.melt(final_result, id_vars =['Site Code'], value_vars =['Rank 1','Rank 2','Rank 3','Rank 4','Rank 5'],value_name ='Rank')
        Competitor = pd.melt(final_result, id_vars =['Site Code'], value_vars =['Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5'],value_name = 'Competitor')
        Brand = pd.melt(final_result, id_vars =['Site Code'], value_vars =['Competitor 1 Brand','Competitor 2 Brand','Competitor 3 Brand','Competitor 4 Brand','Competitor 5 Brand'],value_name = 'Competitor Brand')
        Competitor_Importance_Diesel_Model = pd.melt(final_result, id_vars =['Site Code'], value_vars =['Competitor 1 Importance Diesel Model','Competitor 2 Importance Diesel Model','Competitor 3 Importance Diesel Model','Competitor 4 Importance Diesel Model','Competitor 5 Importance Diesel Model'],value_name = 'Competitor Importance Unleaded Model')
        Rank = Rank[['Site Code','Rank']]
        Brand = Brand[['Competitor Brand']]
        Competitor = Competitor[['Competitor']]
        Competitor_Importance_Diesel_Model =  Competitor_Importance_Diesel_Model[['Competitor Importance Unleaded Model']]
        sheet1 = pd.concat([Rank, Competitor,Brand, Competitor_Importance_Diesel_Model],axis = 1)
        sheet1['Average importance'] = sheet1['Competitor Importance Unleaded Model'].copy()
        sheet1_final = sheet1[sheet1['Competitor'] != 0]
        sheet1_final.sort_values(by=['Site Code', 'Rank'], inplace=True)       
        return sheet1,sheet1_final
    
    def add_count_column_sheet1(self,df):
        # Create a new column 'Count' with default value 0
        df['Cnt'] = 0
        # Dictionary to store counts of unique rows
        counts = {}
        # Iterate through the DataFrame and update the 'Count' column
        for index, row in df[['Site Code']].iterrows():
            row_tuple = tuple(row)
            if row_tuple in counts:
                counts[row_tuple] += 1
            else:
                counts[row_tuple] = 1
            df.at[index, 'Cnt'] = counts[row_tuple]
        return df

    def add_count_sheet1(self,final_result):
        sheet1,sheet1_final = self.data_setup_sheet1(final_result)
        sheet1_final = self.add_count_column_sheet1(sheet1_final)
        sheet1_final['key']  = sheet1_final['Site Code'] + '_' + sheet1_final['Cnt'].astype(str)
        sheet1_final = sheet1_final[['key','Site Code','Rank','Competitor','Competitor Brand','Competitor Importance Unleaded Model','Average importance']]
        return sheet1,sheet1_final

    def add_count_column_model_data(self,df):
        # Create a new column 'Count' with default value 0
        df['Cnt'] = 0
        # Dictionary to store counts of unique rows
        counts = {}
        # Iterate through the DataFrame and update the 'Count' column
        for index, row in df[['Site Code']].iterrows():
            row_tuple = tuple(row)
            if row_tuple in counts:
                counts[row_tuple] += 1
            else:
                counts[row_tuple] = 1
            df.at[index, 'Cnt'] = counts[row_tuple]
        return df

    def count(self,sheet_1):
        sheet_2 = sheet_1[['Site Code','Competitor','Cnt']]
        sheet_2 = pd.pivot_table(sheet_1, values='Competitor', 
                                index='Site Code', 
                                columns='Cnt')
        sheet_2.reset_index(inplace=True)
        sheet_2.rename({1: 'Competitor 1',2: 'Competitor 2',3: 'Competitor 3',4: 'Competitor 4',5: 'Competitor 5',6: 'Competitor 6'}, axis=1, inplace=True)
        sheet_2 = sheet_2[['Site Code','Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5']]
        sheet_2 = sheet_2.reset_index(drop=True)
        return sheet_1,sheet_2

    def merge_model_data_1(self,model_data,sheet_1):
        model_data['Competitor 1'] = model_data['Competitor 1'].astype(int)
        model_data['code1']  = model_data['Importcode'] + '_' + model_data['Competitor 1'].astype(str)
        sheet_1['comp_code'] = sheet_1['Site Code'] + '_' + sheet_1['Competitor'].astype(str)
        sheet_1 = sheet_1.drop_duplicates('comp_code', keep='first')
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Brand']],left_on = 'code1',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Brand': 'Competitor 1 Brand'}, axis=1, inplace=True)
        model_data['Competitor 2'] = model_data['Competitor 2'].fillna(0)
        model_data['Competitor 2'] = model_data['Competitor 2'].astype(int)
        model_data['code2']  = model_data['Importcode'] + '_' + model_data['Competitor 2'].astype(str)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Brand']],left_on = 'code2',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Brand': 'Competitor 2 Brand'}, axis=1, inplace=True)
        model_data['Competitor 3'] = model_data['Competitor 3'].fillna(0)
        model_data['Competitor 3'] = model_data['Competitor 3'].astype(int)
        model_data['code3']  = model_data['Importcode'] + '_' + model_data['Competitor 3'].astype(str)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Brand']],left_on = 'code3',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Brand': 'Competitor 3 Brand'}, axis=1, inplace=True)
        model_data['Competitor 4'] = model_data['Competitor 4'].fillna(0)
        model_data['Competitor 4'] = model_data['Competitor 4'].astype(int)
        model_data['code4']  = model_data['Importcode'] + '_' + model_data['Competitor 4'].astype(str)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Brand']],left_on = 'code4',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Brand': 'Competitor 4 Brand'}, axis=1, inplace=True)
        model_data['Competitor 5'] = model_data['Competitor 5'].fillna(0)
        model_data['Competitor 5'] = model_data['Competitor 5'].astype(int)
        model_data['code5']  = model_data['Importcode'] + '_' + model_data['Competitor 5'].astype(str)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Brand']],left_on = 'code5',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Brand': 'Competitor 5 Brand'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Importance Unleaded Model']],left_on = 'code1',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Importance Unleaded Model': 'Competitor 1 Importance Diesel Model'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Importance Unleaded Model']],left_on = 'code2',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Importance Unleaded Model': 'Competitor 2 Importance Diesel Model'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Importance Unleaded Model']],left_on = 'code3',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Importance Unleaded Model': 'Competitor 3 Importance Diesel Model'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Importance Unleaded Model']],left_on = 'code4',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Importance Unleaded Model': 'Competitor 4 Importance Diesel Model'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_1[['comp_code','Competitor Importance Unleaded Model']],left_on = 'code5',right_on = 'comp_code',how = 'left').drop('comp_code',axis = 1)
        model_data.rename({'Competitor Importance Unleaded Model': 'Competitor 5 Importance Diesel Model'}, axis=1, inplace=True)
        model_data.drop(['code1', 'code2', 'code3', 'code4', 'code5'], axis=1,inplace = True)   
        return model_data

    def column_setup_model_data(self,model_data):
        model_data_final = model_data[['BP Site', 'Importcode', 'Final Diesel Elasticity',
       'Elasticity source', 'R_squared',
        'Competitor 1', 'Competitor 2',
       'Competitor 3', 'Competitor 4', 'Competitor 5',
       'Competitor 1 Brand', 'Competitor 2 Brand', 
       'Competitor 3 Brand', 'Competitor 4 Brand', 
       'Competitor 5 Brand', 'Competitor 1 Importance Diesel Model',
       'Competitor 2 Importance Diesel Model',
       'Competitor 3 Importance Diesel Model',
       'Competitor 4 Importance Diesel Model',
       'Competitor 5 Importance Diesel Model','Final Diesel (04:00-10:00) Elasticity',
       'Final Diesel (10:00-13:00) Elasticity',
       'Final Diesel (13:00-16:00) Elasticity',
       'Final Diesel (16:00-22:00) Elasticity',
        'District']]
        return model_data_final    
 
    def create_workbook_with_sheets(self,sheet_names):
        workbook =openpyxl.Workbook()
        for sheet_name in sheet_names:
            workbook.create_sheet(title=sheet_name)
        return workbook
        
    def workbook_creation(self,workbook,df,sheet_name):
        for r in dataframe_to_rows(df, index=True, header=True):
            workbook[sheet_name].append(r)      
        return workbook,workbook[sheet_name] 
        
    def adjust_column_widths_and_alignment(self,workbook):
        # Iterate over worksheets
        for worksheet in workbook.worksheets:
            # Adjust column widths based on content
            for column_cells in worksheet.columns:
                max_length = 0
                for cell in column_cells:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except TypeError:
                        pass
                    adjusted_width = (max_length + 1) * 1.1  # Add padding and multiply by a factor for better readability
                    worksheet.column_dimensions[cell.column_letter].width = adjusted_width 
        return workbook

    def remove_index_column_from_workbook(self,workbook):
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            # Make sure the sheet has more than one column
            if sheet.max_column > 1:  
                sheet.delete_cols(1)  # Delete the first column (index column)
                sheet.delete_rows(idx=2,amount=1)

    def writing_excel(self):
        top_10_final,top_10 = self.merge_file()
        wm_tslot,wm_tslot_pivot = self.file_reading_wm_tslot()
        Str1_Dies = self.merge_data()
        off_set = self.file_reading_off_set()[0]
        off_set_diesel1_final,off_set_super1_final = self.reset_columns()
        bp_master_inscope = self.merge_data_with_BP_master_sheet2()
        #final_data = self.corel(bp_master_inscope)
        Final_Results_Diesel1 = self.column_setup_final(bp_master_inscope)
        Final_Results_Diesel = Final_Results_Diesel1.copy()
        Final_Results_Diesel.drop_duplicates(subset=['Site Code'], keep='first',inplace=True)

        # create sheet for break down
        breakdown = self.file_reading_final()[6]
        breakdown1 = pd.merge(breakdown,Final_Results_Diesel[['BP Site','District','Elasticity source']],left_on = 'external_site_ref',right_on = 'BP Site',how = 'left').drop('BP Site' , axis =1)
        final_result = Final_Results_Diesel[['Site Code','Rank 1','Rank 2','Rank 3','Rank 4','Rank 5','Competitor 1','Competitor 2','Competitor 3','Competitor 4','Competitor 5','Competitor 1 Brand','Competitor 2 Brand','Competitor 3 Brand','Competitor 4 Brand','Competitor 5 Brand','Competitor 1 Importance Diesel Model','Competitor 2 Importance Diesel Model','Competitor 3 Importance Diesel Model','Competitor 4 Importance Diesel Model','Competitor 5 Importance Diesel Model']]
        final_result.drop_duplicates(subset=['Site Code'], keep='first',inplace=True)
        sheet1,sheet1_final = self.add_count_sheet1(final_result)
        # work for final sheet 
        sheet_1 = sheet1_final[['Site Code','Competitor','Competitor Brand','Competitor Importance Unleaded Model']]
        model_data = Final_Results_Diesel[['BP Site','Site Code','Final Diesel Elasticity','Elasticity source','R_squared','Final Diesel (04:00-10:00) Elasticity',
       'Final Diesel (10:00-13:00) Elasticity',
       'Final Diesel (13:00-16:00) Elasticity',
       'Final Diesel (16:00-22:00) Elasticity','District']]
        sheet_1 = self.add_count_column_model_data(sheet_1)
        sheet_1,sheet_2 = self.count(sheet_1)
        model_data.rename({'Site Code': 'Importcode'}, axis=1, inplace=True)
        model_data = pd.merge(model_data,sheet_2,left_on='Importcode', right_on='Site Code', how='right').drop('Site Code', axis=1)
        model_data = self.merge_model_data_1(model_data,sheet_1)
        model_data_final = self.column_setup_model_data(model_data)
        Comp_mapping_new = self.data_setup()[1]
        master_sheet2 = pd.read_csv(self.path7)
        master_sheet2.rename({'importcode': 'importcode2'}, axis=1, inplace=True)
 
        if(current_mon==base_month):
            lst_dfs=[top_10_final,top_10,wm_tslot,wm_tslot_pivot,Str1_Dies,off_set_diesel1_final,off_set_super1_final,Final_Results_Diesel,breakdown1,sheet1,sheet1_final,model_data_final,Comp_mapping_new,off_set,master_sheet2]
            lst_name=['top_10_final','top_10','wm_tslot','wm_tslot_pivot','Str1_Dies','off_set_diesel1_final','off_set_super1_final','Final_Results_Diesel','breakdown1','sheet1','sheet1_final','model_data_final','Comp_mapping_new','off_set','master_sheet2']
            workbook1 =self.create_workbook_with_sheets(lst_name)
        else:
            lst_dfs=[top_10_final,top_10,wm_tslot,wm_tslot_pivot,Str1_Dies,off_set_diesel1_final,off_set_super1_final,Final_Results_Diesel,breakdown1,sheet1,sheet1_final,model_data_final,Comp_mapping_new,off_set,master_sheet2]
            lst_name=['top_10_final','top_10','wm_tslot','wm_tslot_pivot','Str1_Dies','off_set_diesel1_final','off_set_super1_final','Final_Results_Diesel','breakdown1','sheet1','sheet1_final','model_data_final','Comp_mapping_new','off_set','master_sheet2']
            workbook1 =self.create_workbook_with_sheets(lst_name)

        for i in range(len(lst_name)):
            self.workbook_creation(workbook1,lst_dfs[i],lst_name[i])
        # Remove index values from the first column of all sheets
        self.remove_index_column_from_workbook(workbook1)
        first_sheet = workbook1.sheetnames[0]
        workbook1.remove(workbook1[first_sheet])
        workbook1=self.adjust_column_widths_and_alignment(workbook1)
        # Save the workbook to a local file
        local_file_path = 'Final_Results_Diesel.xlsx'
        workbook1.save(local_file_path)
        # Specify the S3 bucket and folder path
        bucket_name = self.enrich_bucket
        s3_folder_path =  self.destination_object_key2
        # Upload the local file to the S3 folder
        s3_key = s3_folder_path + f'{self.run_month}_Final_Results_Diesel.xlsx'
        self.s3_client.upload_file(local_file_path, bucket_name, s3_key)
        time.sleep(5)
        return lst_dfs


    def main(self):
        print("all data coming from database through SQL ")

        self.glue_log.info('Main method started')
        self.glue_log.info('Python Shell code started')
        # Create redshift connection
        redshift_conn = RedshiftManager(self.subtenant)
        print("redshift_conn : " + str(redshift_conn))
        self.glue_log.info("Redshift Connection initialized")
        # Set query group
        query_grp_sql = f"SET query_group to '<pipeline_name>'"
        redshift_conn.query(query_grp_sql.replace('<pipeline_name>',self.pipeline))
        self.pipeline_temp = self.pipeline
        temp_table_list = []
        transform_staging_path = f"custom/main/{self.subtenant}/transform_main_{self.subtenant}/{self.pipeline}/staging/"
        conform_staging_path = f"main/{self.subtenant}/conform_main_{self.subtenant}/{self.pipeline}/staging/"
        enrich_staging_path = f"main/{self.subtenant}/enrich_main_{self.subtenant}/{self.pipeline}/staging/"

        # Staging path cleanup before the program crawler_start_status
        self._dataCleanUpProcess(transform_staging_path, self.transform_bucket)
        self._dataCleanUpProcess(conform_staging_path, self.conform_bucket)
        self._dataCleanUpProcess(enrich_staging_path, self.enrich_bucket)
        # Stage path cleanup completed
        try:
            self.sql_details = self.yaml_data['sql_details']
            self.glue_log.info("SQL Details : " + str(self.sql_details))
            self.glue_log.info("SQL Details type : " + str(type(self.sql_details)))
            for dcn in self.sql_details:
                self.glue_log.info("Dictionary value assignment Started")
                sql_details_name = dcn['name']
                table_type = dcn['table_type']
                self.sql_query = dcn['sql_query']
                self.tgt_tbl_name = dcn['tgt_tbl_name']
                self.tgt_db_name = dcn['tgt_db_name']
                self.tbl_load_type = dcn['tbl_load_type']
                self.target_zone = dcn['target_zone']
                #self.unload_iam_role = dcn['unload_iam_role']
                self.glue_log.info("Dictionary value assignment Completed")
                if self.target_zone == 'transform':
                    self.target_bucket = self.transform_bucket
                    staging_path = transform_staging_path
                elif self.target_zone == 'conform':
                    self.target_bucket = self.conform_bucket
                    staging_path = conform_staging_path
                elif self.target_zone == 'enrich':
                    self.target_bucket = self.enrich_bucket
                    staging_path = enrich_staging_path

                if table_type == 'redshift_temp_tbl' and sql_details_name == 'gen_query':
                    self.glue_log.info("Inside Redshift temporary table creation block")
                    query_resp = redshift_conn.query(self.sql_query)
                    
                    print(query_resp)
                    query_resp
                    self.glue_log.info(query_resp)
                   

                elif table_type == 'external_glue_txt':
                        if self.target_zone == 'transform':
                            self.tgt_path = 'custom/main/' + self.subtenant + '/' + self.tgt_db_name + '/' + self.tgt_tbl_name
                        else:
                            self.tgt_path = 'main/' + self.subtenant + '/' + self.tgt_db_name + '/' + 'DE/AFP/'+self.run_month+'/final_model/Output/' + self.tgt_tbl_name
                        self.glue_log.info("External Glue table creation block")
                        self.tgt_s3_path = 's3://' + self.target_bucket +  "/" + self.tgt_path
                        if self.tbl_load_type == 'FL':
                            self._dataCleanUpProcess(self.tgt_path + "/", self.target_bucket)
                        self.unload_path = self.tgt_s3_path+'/'+self.tgt_tbl_name+'.txt'
                        self.sql_query = (self.sql_query).format(unload_path = self.unload_path, unload_iam_role = self.unload_iam_role,lst_day = last_work_day_1)
                        query_resp = redshift_conn.query(self.sql_query)
                        print(query_resp)
                        self.glue_log.info("External Glue table created : " + str(self.tgt_tbl_name))
            
            # Cleaning temp path
            self.glue_log.info('Cleaning temp folders from s3 path started.')
            self._dataCleanUpProcess(transform_staging_path, self.transform_bucket)
            self.glue_log.info('Cleaning temp staging folder from s3 path - ' + self.transform_bucket + '/'+ transform_staging_path)
            self._dataCleanUpProcess(conform_staging_path, self.conform_bucket)
            self.glue_log.info('Cleaning temp staging folder from ' + self.conform_bucket +'/'+ conform_staging_path)
            self._dataCleanUpProcess(enrich_staging_path, self.enrich_bucket)
            self.glue_log.info('Cleaning temp staging folder from s3 path - ' + self.enrich_bucket +'/'+ enrich_staging_path)
            for tbldel in temp_table_list:
                dbname = tbldel.split(".")[0]
                tblame = tbldel.split(".")[1]
                self._delete_glue_table(dbname, tblame)

        except:
            self.glue_log.info('Error')

        lst_dfs=self.writing_excel()
           

if __name__ == "__main__":
    final_mdl(cli_args=['SUBTENANT', 'TENANT', 'PIPELINE', 'ACCOUNT', 'ENV', 'PEH_ID','YAML_CONFIG_PATH', 'UNLOAD_IAM_ROLE'])